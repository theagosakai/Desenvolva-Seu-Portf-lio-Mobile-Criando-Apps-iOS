# LABs

## 044_CriandoUmAppParaApresentarSeuPortfolioDoGitHub
Crie um App Android para apresentar seu portfólio de projetos do GitHub de maneira elegante e simplificada. Nesse contexto, você passará por todo o processo de desenvolvimento usando o Kotlin, uma das linguagens de programação de maior ascensão nos últimos anos. Por fim, você é desafiado a entregar seu próprio projeto, incorporando suas próprias evoluções e melhorias! Está preparado?

##### Ezequiel Messore
Android Developer, Digital Innovation One

https://web.digitalinnovation.one/project/criando-um-app-para-apresentar-seu-portfolio-do-github/learning/3735829a-af5e-4473-a3f4-9fe3a3f72fe1?back=/track/inter-android-developer
